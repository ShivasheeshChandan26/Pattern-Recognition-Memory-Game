const a =  document.querySelectorAll(".a_b")
var arr = [0];
const max = 15;
const min = 0;

var timeleft = 7;

const numberOfBoxes = 5;

document.getElementById('display').style.visibility = "hidden";
document.getElementById('progressBar').style.visibility = "hidden";

while(arr.length < numberOfBoxes){
    let r = Math.floor(Math.random() * (max - min + 1)) + min;
    if(arr.indexOf(r) === -1) arr.push(r);
}

window.localStorage.setItem('Random Number List', arr)
console.log(arr); // just for debugging

 let count = 0

setInterval(() => {
    if (count <= numberOfBoxes) {
        let count2 = 0
        a.forEach((b) => {
            if (count2 == arr[count]) {
                b.style.backgroundColor = "#1DA2DC"
            }
            count2 += 1;
        })
    }
    count += 1
}, 1000)

setInterval(removeBoxes, 7000);
function removeBoxes() {
    var div = document.getElementById('rand');
    while(div.firstChild){
        div.removeChild(div.firstChild);
    }
    document.getElementById('display').style.visibility = "visible";
    document.getElementById('progressBar').style.visibility = "visible";
    
    var downloadTimer = setInterval(function(){
        if(timeleft <= 0){
          clearInterval(downloadTimer);
        }
        document.getElementById("display").innerHTML = "You have " + timeleft + " seconds!";
        document.getElementById("progressBar").value = timeleft;
        if(timeleft == 0) window.location.href = "gameOver.html";
        timeleft -= 1;
      }, 1000);

}

function winLevel() {
    // some function
}

function gameOver() {
    //some function
}

var Signal = []; //signal array from python
for(let i = 0; i < numberOfBoxes; i++) {
    if(arr[i] == Signal[i]) {
        winLevel();
    }
    else {
        gameOver();
    }
}