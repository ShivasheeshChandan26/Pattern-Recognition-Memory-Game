var sessionString = sessionStorage.getItem('boxOrder_final3');
var boxOrder_final3 = JSON.parse(sessionString);
console.log(boxOrder_final3);

var userBox = [];
const numberOfBoxes = 7;

function get0() {
    userBox.push(0);
    document.getElementById("a_1").style.backgroundColor = "#F7C232";
}

function get1() {
    userBox.push(1);
    document.getElementById("a_2").style.backgroundColor = "#F7C232";
}
function get2() {
    userBox.push(2);
    document.getElementById("a_3").style.backgroundColor = "#F7C232";
}
function get3() {
    userBox.push(3);
    document.getElementById("a_4").style.backgroundColor = "#F7C232";
}
function get4() {
    userBox.push(4);
    document.getElementById("b_1").style.backgroundColor = "#F7C232";
}
function get5() {
    userBox.push(5);
    document.getElementById("b_2").style.backgroundColor = "#F7C232";
}
function get6() {
    userBox.push(6);
    document.getElementById("b_3").style.backgroundColor = "#F7C232";
}
function get7() {
    userBox.push(7);
    document.getElementById("b_4").style.backgroundColor = "#F7C232";
}
function get8() {
    userBox.push(8);
    document.getElementById("c_1").style.backgroundColor = "#F7C232";
}
function get9() {
    userBox.push(9);
    document.getElementById("c_2").style.backgroundColor = "#F7C232";
}
function get10() {
    userBox.push(10);
    document.getElementById("c_3").style.backgroundColor = "#F7C232";
}
function get11() {
    userBox.push(11);
    document.getElementById("c_4").style.backgroundColor = "#F7C232";
}
function get12() {
    userBox.push(12);
    document.getElementById("d_1").style.backgroundColor = "#F7C232";
}
function get13() {
    userBox.push(13);
    document.getElementById("d_2").style.backgroundColor = "#F7C232";
}
function get14() {
    userBox.push(14); 
    document.getElementById("d_3").style.backgroundColor = "#F7C232";
}
function get15() {
    userBox.push(15); 
    document.getElementById("d_4").style.backgroundColor = "#F7C232";
}

function matchingArray() {
    count = 0;
    for(var i = 0; i < numberOfBoxes; i++) {
        if(userBox[i] != null) {
            if(userBox[i] == boxOrder_final3[i]) {
                count++;
                console.log(count);
            }
            else {
                gameOver();
            }
        }
    }
    if(userBox[numberOfBoxes-1] != null) {
        if(count == numberOfBoxes) {
            winLevel();
        }
        else {
            timeleft = 0;
            gameOver();
        }
    }
}
matchingArray();
setInterval(matchingArray, 1000);

function winLevel() {
    window.location.href = "level_4.html";
}

function gameOver() {
    $("body").empty();
    var displayScore = document.createElement("p");
    var text = document.createTextNode("Score : " + (8+count) + "\n" + "You have good memory power but improve it more!");
    displayScore.appendChild(text);
    var element = document.body;
    element.appendChild(displayScore);
    
    displayScore.style.position = "absolute";
    displayScore.style.top = "37.5%";
    displayScore.style.color = "#FFF";
    displayScore.style.left = "15%";
    displayScore.style.fontSize = "50px";
    displayScore.style.fontFamily = "Press Start 2P";

    document.body.style.background = "url('gameOverBackground.jpg') no-repeat";
    document.body.style.backgroundSize = "cover";
}

var timeleft = 15;
var timerId = setInterval(countdown, 1000);

function countdown() {
    if(timeleft == -1) {
        clearInterval(timerId);
    }
    else {
        document.getElementById("display").innerHTML = "You have " + timeleft + " seconds!";
        document.getElementById("progressBar").value = timeleft;
        timeleft -= 1;
    }
}

setInterval(gameOver, 16000);